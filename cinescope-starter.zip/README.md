# CineScope – Free Movie Website (TMDb)

A single-file movie website you can host **free** on GitHub Pages, Netlify or Vercel.

## 1) Get a free TMDb API key
- Create an account at The Movie Database (TMDb)
- In your account settings > API, request a **Developer** key.
- Copy your API key.

## 2) Put your API key into the code
- Open `index.html`, find `const TMDB_API_KEY = 'YOUR_TMDB_API_KEY'` and replace it with your key.

## 3) Run locally (optional)
- Just double-click `index.html`.
- If posters or data don't show due to browser CORS, use a tiny local server:
  - Python 3: `python -m http.server 8080` then visit `http://localhost:8080`.

## 4) Deploy FREE (choose one)
### GitHub Pages
1. Create a new repo (e.g., `movie-site`).
2. Upload `index.html`.
3. Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.
4. Your site will appear at `https://USERNAME.github.io/movie-site/`.

### Netlify (drag & drop)
1. Go to app.netlify.com → New site from Git → drag & drop the folder.
2. Netlify gives you a free `.netlify.app` URL.

### Vercel
1. Import the repo at vercel.com → Deploy.

## 5) Legal note
This template **does not host movies**. It shows public metadata, posters and trailers via TMDb/YouTube. Streaming full movies requires proper rights.

## 6) Credits
“This product uses the TMDb API but is not endorsed or certified by TMDb.”
